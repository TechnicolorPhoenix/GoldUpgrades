package com.titanhex.goldupgrades.item.custom.inter;

public interface IJumpBoostArmor {
    double getJumpBoostModifier();
}
