package com.titanhex.goldupgrades.integrations.jei;

public class GoldUpgradesJei {
}
